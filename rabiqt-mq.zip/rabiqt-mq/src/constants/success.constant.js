const SUCCESS_MESSAGES = {
  SUCCESS_LOAN: "Empréstimo processado com sucesso, Aproveite seu livro",
  SUCCESS_RETURN_BOOK: "Devolução registrada com sucesso!",
};

export { SUCCESS_MESSAGES };
